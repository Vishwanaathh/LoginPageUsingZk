package fiddle;

import org.zkoss.zk.ui.*;
import org.zkoss.zk.ui.event.*;
import org.zkoss.zk.ui.util.*;
import org.zkoss.zk.ui.ext.*;
import org.zkoss.zk.au.*;
import org.zkoss.zk.au.out.*;
import org.zkoss.zul.*;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;
import org.zkoss.zul.Button;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zk.ui.select.SelectorComposer;


public class Controller extends SelectorComposer<Component>{
  public Person admin=new Person("Admin","0");
  
  @Wire
  public Textbox Namee;
  @Wire
  public Textbox Idd;
  @Wire
  public Button butt;
  @Listen("onClick = #butt")
    public void onSaveButtonClick() {
        // Update admin's data with the values entered in textboxes
        admin.setName(Namee.getValue());
        admin.setId(Idd.getValue());
                if(admin.Name.equals("Admin")){
          Clients.showNotification(admin.Name);
          if(admin.Id.equals("0")){
            Clients.showNotification("successful login!");
            
            
            
          }
       
          
          
          
        }
        
     
      

    }
  
 
  
  


}
