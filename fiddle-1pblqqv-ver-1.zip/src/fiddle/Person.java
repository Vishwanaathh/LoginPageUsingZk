package fiddle;

import org.zkoss.zk.ui.*;
import org.zkoss.zk.ui.event.*;
import org.zkoss.zk.ui.util.*;
import org.zkoss.zk.ui.ext.*;
import org.zkoss.zk.au.*;
import org.zkoss.zk.au.out.*;
import org.zkoss.zul.*;

public class Person{
    public String Name;
    public String Id;
    public Person(String a,String b){
     Name=a;
      Id=b;
     
    }
    public void setName(String c){
      Name=c;
      
    }
    public void setId(String d){
      
     Id=d; 
      
    }
  
}
